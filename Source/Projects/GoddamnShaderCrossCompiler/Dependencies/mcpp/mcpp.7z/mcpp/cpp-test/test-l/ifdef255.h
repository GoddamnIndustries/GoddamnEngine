/* ifdef255.h   */

#ifdef  X80
#else
#ifdef  X81
#else
#ifdef  X82
#else
#ifdef  X83
#else
#ifdef  X84
#else
#ifdef  X85
#else
#ifdef  X86
#else
#ifdef  X87
#else
#ifdef  X88
#else
#ifdef  X89
#else
#ifdef  X8A
#else
#ifdef  X8B
#else
#ifdef  X8C
#else
#ifdef  X8D
#else
#ifdef  X8E
#else
#ifdef  X8F
#else
#ifdef  X90
#else
#ifdef  X91
#else
#ifdef  X92
#else
#ifdef  X93
#else
#ifdef  X94
#else
#ifdef  X95
#else
#ifdef  X96
#else
#ifdef  X97
#else
#ifdef  X98
#else
#ifdef  X99
#else
#ifdef  X9A
#else
#ifdef  X9B
#else
#ifdef  X9C
#else
#ifdef  X9D
#else
#ifdef  X9E
#else
#ifdef  X9F
#else
#ifdef  XA0
#else
#ifdef  XA1
#else
#ifdef  XA2
#else
#ifdef  XA3
#else
#ifdef  XA4
#else
#ifdef  XA5
#else
#ifdef  XA6
#else
#ifdef  XA7
#else
#ifdef  XA8
#else
#ifdef  XA9
#else
#ifdef  XAA
#else
#ifdef  XAB
#else
#ifdef  XAC
#else
#ifdef  XAD
#else
#ifdef  XAE
#else
#ifdef  XAF
#else
#ifdef  XB0
#else
#ifdef  XB1
#else
#ifdef  XB2
#else
#ifdef  XB3
#else
#ifdef  XB4
#else
#ifdef  XB5
#else
#ifdef  XB6
#else
#ifdef  XB7
#else
#ifdef  XB8
#else
#ifdef  XB9
#else
#ifdef  XBA
#else
#ifdef  XBB
#else
#ifdef  XBC
#else
#ifdef  XBD
#else
#ifdef  XBE
#else
#ifdef  XBF
#else
#ifdef  XC0
#else
#ifdef  XC1
#else
#ifdef  XC2
#else
#ifdef  XC3
#else
#ifdef  XC4
#else
#ifdef  XC5
#else
#ifdef  XC6
#else
#ifdef  XC7
#else
#ifdef  XC8
#else
#ifdef  XC9
#else
#ifdef  XCA
#else
#ifdef  XCB
#else
#ifdef  XCC
#else
#ifdef  XCD
#else
#ifdef  XCE
#else
#ifdef  XCF
#else
#ifdef  XD0
#else
#ifdef  XD1
#else
#ifdef  XD2
#else
#ifdef  XD3
#else
#ifdef  XD4
#else
#ifdef  XD5
#else
#ifdef  XD6
#else
#ifdef  XD7
#else
#ifdef  XD8
#else
#ifdef  XD9
#else
#ifdef  XDA
#else
#ifdef  XDB
#else
#ifdef  XDC
#else
#ifdef  XDD
#else
#ifdef  XDE
#else
#ifdef  XDF
#else
#ifdef  XE0
#else
#ifdef  XE1
#else
#ifdef  XE2
#else
#ifdef  XE3
#else
#ifdef  XE4
#else
#ifdef  XE5
#else
#ifdef  XE6
#else
#ifdef  XE7
#else
#ifdef  XE8
#else
#ifdef  XE9
#else
#ifdef  XEA
#else
#ifdef  XEB
#else
#ifdef  XEC
#else
#ifdef  XED
#else
#ifdef  XEE
#else
#ifdef  XEF
#else
#ifdef  XF0
#else
#ifdef  XF1
#else
#ifdef  XF2
#else
#ifdef  XF3
#else
#ifdef  XF4
#else
#ifdef  XF5
#else
#ifdef  XF6
#else
#ifdef  XF7
#else
#ifdef  XF8
#else
#ifdef  XF9
#else
#ifdef  XFA
#else
#ifdef  XFB
#else
#ifdef  XFC
#else
#ifdef  XFD
#else
#ifdef  XFE
#else
#ifdef  XFF
    ifdef_nest = 0xff;
#else
    ifdef_nest = 0xff;
#endif  /* XFF  */
#endif  /* XFE  */
#endif  /* XFD  */
#endif  /* XFC  */
#endif  /* XFB  */
#endif  /* XFA  */
#endif  /* XF9  */
#endif  /* XF8  */
#endif  /* XF7  */
#endif  /* XF6  */
#endif  /* XF5  */
#endif  /* XF4  */
#endif  /* XF3  */
#endif  /* XF2  */
#endif  /* XF1  */
#endif  /* XF0  */
#endif  /* XEF  */
#endif  /* XEE  */
#endif  /* XED  */
#endif  /* XEC  */
#endif  /* XEB  */
#endif  /* XEA  */
#endif  /* XE9  */
#endif  /* XE8  */
#endif  /* XE7  */
#endif  /* XE6  */
#endif  /* XE5  */
#endif  /* XE4  */
#endif  /* XE3  */
#endif  /* XE2  */
#endif  /* XE1  */
#endif  /* XE0  */
#endif  /* XDF  */
#endif  /* XDE  */
#endif  /* XDD  */
#endif  /* XDC  */
#endif  /* XDB  */
#endif  /* XDA  */
#endif  /* XD9  */
#endif  /* XD8  */
#endif  /* XD7  */
#endif  /* XD6  */
#endif  /* XD5  */
#endif  /* XD4  */
#endif  /* XD3  */
#endif  /* XD2  */
#endif  /* XD1  */
#endif  /* XD0  */
#endif  /* XCF  */
#endif  /* XCE  */
#endif  /* XCD  */
#endif  /* XCC  */
#endif  /* XCB  */
#endif  /* XCA  */
#endif  /* XC9  */
#endif  /* XC8  */
#endif  /* XC7  */
#endif  /* XC6  */
#endif  /* XC5  */
#endif  /* XC4  */
#endif  /* XC3  */
#endif  /* XC2  */
#endif  /* XC1  */
#endif  /* XC0  */
#endif  /* XBF  */
#endif  /* XBE  */
#endif  /* XBD  */
#endif  /* XBC  */
#endif  /* XBB  */
#endif  /* XBA  */
#endif  /* XB9  */
#endif  /* XB8  */
#endif  /* XB7  */
#endif  /* XB6  */
#endif  /* XB5  */
#endif  /* XB4  */
#endif  /* XB3  */
#endif  /* XB2  */
#endif  /* XB1  */
#endif  /* XB0  */
#endif  /* XAF  */
#endif  /* XAE  */
#endif  /* XAD  */
#endif  /* XAC  */
#endif  /* XAB  */
#endif  /* XAA  */
#endif  /* XA9  */
#endif  /* XA8  */
#endif  /* XA7  */
#endif  /* XA6  */
#endif  /* XA5  */
#endif  /* XA4  */
#endif  /* XA3  */
#endif  /* XA2  */
#endif  /* XA1  */
#endif  /* XA0  */
#endif  /* X9F  */
#endif  /* X9E  */
#endif  /* X9D  */
#endif  /* X9C  */
#endif  /* X9B  */
#endif  /* X9A  */
#endif  /* X99  */
#endif  /* X98  */
#endif  /* X97  */
#endif  /* X96  */
#endif  /* X95  */
#endif  /* X94  */
#endif  /* X93  */
#endif  /* X92  */
#endif  /* X91  */
#endif  /* X90  */
#endif  /* X8F  */
#endif  /* X8E  */
#endif  /* X8D  */
#endif  /* X8C  */
#endif  /* X8B  */
#endif  /* X8A  */
#endif  /* X89  */
#endif  /* X88  */
#endif  /* X87  */
#endif  /* X86  */
#endif  /* X85  */
#endif  /* X84  */
#endif  /* X83  */
#endif  /* X82  */
#endif  /* X81  */
#endif  /* X80  */
