/* unbal2.h */

#define UNBAL2  1

#if     UNBAL2      /* line 5   */
#else
