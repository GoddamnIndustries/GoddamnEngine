/* unbal6.h */
#define UNBAL6( a, b)    ((a) + (b))
    UNBAL6
        (
        x
        ,
