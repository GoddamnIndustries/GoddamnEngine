MCPP is a portable C/C++ preprocessor. It was hosted on
[sourceforge](http://sourceforge.net/projects/mcpp/), and has not been updated
since 2008. 

The author is Kiyoshi Matsui <kmatsui@t3.rim.or.jp>.

This is just a github mirror of the original one.

**Patching**

I applied a [patch](https://trac.macports.org/attachment/ticket/30036/patch-mcpp-comment-parsing-fix)
that fixes the line comment bug when `-C` and `-P` are both used.
